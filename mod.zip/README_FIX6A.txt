MadAnchor FIX6-A — MC 1.21.11 Fabric

Purpose: isolate the AutoTotem subsystem.

Changes:
- Disabled GameRendererMixin (Totem use hook).
- Disabled HandledScreenMixin (AutoTotem inventory/cursor hook).
- AutoTotemManager/TotemHelper source remains in the project but is not triggered by mixins.
- Anchor macro code is otherwise unchanged from FIX5.

Test:
1. Build with GitHub Actions.
2. Install only the generated MadAnchor jar.
3. Enter a singleplayer world and wait 1–2 minutes.
4. Test joining the server.

Interpretation:
- No crash/lag: AutoTotem path is implicated.
- Crash remains: AutoTotem mixin hooks are ruled out; continue with AnchorStateMachine / other client hooks.
