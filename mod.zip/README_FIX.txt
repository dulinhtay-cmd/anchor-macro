MadAnchor 1.21.11 fix
=====================

The original project was built for Minecraft 1.21.1, while the target client
is Minecraft 1.21.11. The crash was caused by the old HandledScreenMixin
refmap/target during Mixin APPLY.

Changes:
- Minecraft 1.21.11
- Yarn 1.21.11+build.4
- Fabric Loader 0.19.3
- Fabric API 0.141.6+1.21.11
- Fabric Loom 1.14
- Mod Menu 17.0.0
- Cloth Config 21.11.153
- Replaced the fragile drawSlot injection with a drawSlots injection that
  scans the current handler slots for the Totem.

Build on Windows:
  gradlew.bat clean build

Output:
  build\libs\madanchor-1.0.0.jar

Put that jar in the same mods folder where the old madanchor-1.0.0.jar was.
Do not keep both copies at the same time.
