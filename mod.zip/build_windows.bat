@echo off
setlocal
cd /d "%~dp0"
if not exist "gradle\wrapper\gradle-wrapper.jar" (
  echo ERROR: Gradle wrapper is missing.
  exit /b 1
)
echo Building MadAnchor for Minecraft 1.21.11 + Fabric...
call gradlew.bat clean build --no-daemon
if errorlevel 1 (
  echo.
  echo BUILD FAILED. Keep this window open and send me the error above.
  exit /b 1
)
echo.
echo BUILD SUCCESS.
echo JAR files:
dir /b build\libs\*.jar
endlocal
