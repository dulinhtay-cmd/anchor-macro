package net.madanchor.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.madanchor.config.ModConfig;
import net.madanchor.macro.AnchorStateMachine;
import net.madanchor.ui.HudOverlay;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.glfw.GLFW;

public class MadAnchorClient implements ClientModInitializer {

    private static final KeyBinding.Category MADANCHOR_CATEGORY =
        new KeyBinding.Category(Identifier.of("madanchor", "general"));
    
    private static KeyBinding toggleMadAnchorKey;
    private static KeyBinding toggleSafeAnchorKey;
    private static KeyBinding toggleAutoTotemKey;
    private static KeyBinding cancelKey;
    private static KeyBinding openConfigKey;
    
    @Override
    public void onInitializeClient() {
        ModConfig.load();
        
        toggleMadAnchorKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.madanchor.toggle_mad",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_M,
            MADANCHOR_CATEGORY
        ));
        
        toggleSafeAnchorKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.madanchor.toggle_safe",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_N,
            MADANCHOR_CATEGORY
        ));

        toggleAutoTotemKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.madanchor.toggle_autototem",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_B,
            MADANCHOR_CATEGORY
        ));
        
        cancelKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.madanchor.cancel",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_V,
            MADANCHOR_CATEGORY
        ));

        openConfigKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.madanchor.open_config",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_O,
            MADANCHOR_CATEGORY
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;
            
            while (openConfigKey.wasPressed()) {
                client.setScreen(net.madanchor.config.ConfigScreen.createScreen(client.currentScreen));
            }
            
            while (toggleMadAnchorKey.wasPressed()) {
                ModConfig.INSTANCE.madAnchorEnabled = !ModConfig.INSTANCE.madAnchorEnabled;
                ModConfig.save();
                client.player.sendMessage(Text.literal("Mad Anchor: " + (ModConfig.INSTANCE.madAnchorEnabled ? "ON" : "OFF")), true);
            }
            while (toggleSafeAnchorKey.wasPressed()) {
                ModConfig.INSTANCE.safeAnchorEnabled = !ModConfig.INSTANCE.safeAnchorEnabled;
                ModConfig.save();
                client.player.sendMessage(Text.literal("Safe Anchor: " + (ModConfig.INSTANCE.safeAnchorEnabled ? "ON" : "OFF")), true);
            }
            while (toggleAutoTotemKey.wasPressed()) {
                ModConfig.INSTANCE.autoTotem.enabled = !ModConfig.INSTANCE.autoTotem.enabled;
                ModConfig.save();
                client.player.sendMessage(Text.literal("AutoTotem: " + (ModConfig.INSTANCE.autoTotem.enabled ? "ON" : "OFF")), true);
            }
            while (cancelKey.wasPressed()) {
                AnchorStateMachine.INSTANCE.cancel();
                client.player.sendMessage(Text.literal("Macro Cancelled!"), true);
            }
            
            try {
                AnchorStateMachine.INSTANCE.tick();
            } catch (Throwable t) {
                System.err.println("[MadAnchor] Tick error - cancelling macro: " + t);
                t.printStackTrace();
                AnchorStateMachine.INSTANCE.cancel();
            }
        });
        
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (world.isClient() && ModConfig.INSTANCE.madAnchorEnabled) {
                ItemStack stack = player.getStackInHand(hand);
                if (stack.isOf(Items.RESPAWN_ANCHOR)) {
                    BlockPos placePos = hitResult.getBlockPos();
                    if (!world.getBlockState(placePos).isReplaceable()) {
                        placePos = placePos.offset(hitResult.getSide());
                    }
                    AnchorStateMachine.INSTANCE.start(placePos);
                }
            }
            return ActionResult.PASS;
        });

        HudOverlay.init();
    }
}
