package net.madanchor.inventory;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class HotbarManager {
    
    public static int findItemInHotbar(Item item) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return -1;
        
        PlayerInventory inv = client.player.getInventory();
        for (int i = 0; i < 9; i++) {
            ItemStack stack = inv.getStack(i);
            if (!stack.isEmpty() && stack.isOf(item)) {
                return i;
            }
        }
        return -1;
    }
    
    public static boolean switchToSlot(int slot) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return false;
        
        if (slot >= 0 && slot < 9) {
            client.player.getInventory().selectedSlot = slot;
            // Depending on the exact 1.21.x networking, setting selectedSlot local is sufficient as 
            // the server is synced via UpdateSelectedSlotC2SPacket in the player tick, but we should 
            // ensure it's sent immediately if we act on it in the same tick.
            client.getNetworkHandler().sendPacket(new net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket(slot));
            return true;
        }
        return false;
    }
    
    public static int getCurrentSlot() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return 0;
        return client.player.getInventory().selectedSlot;
    }
}
