package net.madanchor.ui;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.madanchor.config.ModConfig;
import net.madanchor.macro.AnchorStateMachine;
import net.madanchor.macro.MacroState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public class HudOverlay {
    public static void init() {
        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            if (!ModConfig.INSTANCE.enableHud) return;
            
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null) return;
            
            MacroState state = AnchorStateMachine.INSTANCE.getCurrentState();
            
            TextRenderer textRenderer = client.textRenderer;
            int y = 10;
            int x = 10;
            
            drawContext.drawText(textRenderer, "Mad Anchor: " + (ModConfig.INSTANCE.madAnchorEnabled ? "ON" : "OFF"), x, y, 0xFFFFFF, true);
            y += 10;
            
            drawContext.drawText(textRenderer, "Safe Anchor: " + (ModConfig.INSTANCE.safeAnchorEnabled ? "ON" : "OFF"), x, y, ModConfig.INSTANCE.safeAnchorEnabled ? 0x00FF00 : 0xFFFFFF, true);
            y += 10;

            drawContext.drawText(textRenderer, "AutoTotem: " + (ModConfig.INSTANCE.autoTotem.enabled ? "ON" : "OFF"), x, y, ModConfig.INSTANCE.autoTotem.enabled ? 0x00FFFF : 0xFFFFFF, true);
            y += 10;
            
            if (state != MacroState.IDLE) {
                drawContext.drawText(textRenderer, "Macro State: " + state.name(), x, y, 0xFFAA00, true);
            }
        });
    }
}
