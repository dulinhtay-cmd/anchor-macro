package net.madanchor.macro;

import net.madanchor.config.ModConfig;
import net.madanchor.input.ClickSimulator;
import net.madanchor.inventory.HotbarManager;
import net.madanchor.totem.InventoryActionCoordinator;
import net.madanchor.totem.InventoryActionCoordinator.ActionOwner;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.text.Text;

public class AnchorStateMachine {
    
    public static AnchorStateMachine INSTANCE = new AnchorStateMachine();
    
    private MacroState currentState = MacroState.IDLE;
    private long stateEnterTime = 0;
    private long currentDelayMs = 0;
    
    private BlockPos anchorPos = null;
    private BlockPos protectionPos = null;
    private int originalSlot = -1;
    
    public void start(BlockPos placedAnchorPos) {
        if (!ModConfig.INSTANCE.madAnchorEnabled) return;
        
        if (!InventoryActionCoordinator.INSTANCE.requestLock(InventoryActionCoordinator.ActionOwner.MAD_ANCHOR)) {
            logDebug("Could not start Mad Anchor, lock denied.");
            return;
        }
        
        this.anchorPos = placedAnchorPos;
        this.originalSlot = HotbarManager.getCurrentSlot();
        transitionTo(MacroState.WAIT_ANCHOR_PLACEMENT_CONFIRM, 50);
        logDebug("Started Mad Anchor sequence for pos " + anchorPos);
    }
    
    public void cancel() {
        if (currentState != MacroState.IDLE) {
            logDebug("Sequence cancelled at state: " + currentState);
            currentState = MacroState.IDLE;
            this.anchorPos = null;
            this.protectionPos = null;
            InventoryActionCoordinator.INSTANCE.releaseLock(InventoryActionCoordinator.ActionOwner.MAD_ANCHOR);
            InventoryActionCoordinator.INSTANCE.releaseLock(InventoryActionCoordinator.ActionOwner.SAFE_ANCHOR);
        }
    }
    
    public void tick() {
        if (currentState == MacroState.IDLE) return;
        
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null || client.player.isDead()) {
            cancel();
            return;
        }
        
        long now = System.currentTimeMillis();
        long elapsed = now - stateEnterTime;
        
        if (elapsed > ModConfig.INSTANCE.actionTimeoutMs) {
            logDebug("Timeout in state " + currentState);
            cancel();
            return;
        }
        
        if (elapsed < currentDelayMs) {
            return;
        }
        
        // Before performing action, ensure we still have the lock (or upgrade to SAFE_ANCHOR if doing protection)
        ActionOwner requiredOwner = (currentState.name().contains("PROTECTION") || ModConfig.INSTANCE.safeAnchorEnabled) 
            ? ActionOwner.SAFE_ANCHOR : ActionOwner.MAD_ANCHOR;
            
        if (!InventoryActionCoordinator.INSTANCE.requestLock(requiredOwner)) {
            logDebug("Preempted! Cancelling.");
            cancel();
            return;
        }
        
        switch (currentState) {
            case WAIT_ANCHOR_PLACEMENT_CONFIRM:
                if (client.world.getBlockState(anchorPos).isOf(Blocks.RESPAWN_ANCHOR)) {
                    transitionTo(MacroState.SWITCH_TO_GLOWSTONE, getSwitchDelay());
                } else if (elapsed > 500) {
                    cancel();
                }
                break;
                
            case SWITCH_TO_GLOWSTONE:
                int glowstoneSlot = ModConfig.INSTANCE.glowstoneSlot > 0 ? (ModConfig.INSTANCE.glowstoneSlot - 1) : HotbarManager.findItemInHotbar(Items.GLOWSTONE);
                if (glowstoneSlot != -1) {
                    HotbarManager.switchToSlot(glowstoneSlot);
                    // Đợi đổi slot xong + đợi thao tác lắp glowstone
                    transitionTo(MacroState.WAIT_SWITCH_GLOWSTONE_DELAY, getSwitchDelay() + getInsertDelay());
                    logDebug("Switched to glowstone slot: " + glowstoneSlot);
                } else {
                    logDebug("Glowstone not found!");
                    cancel();
                }
                break;
                
            case WAIT_SWITCH_GLOWSTONE_DELAY:
                transitionTo(MacroState.INSERT_GLOWSTONE, 0);
                break;
                
            case INSERT_GLOWSTONE:
                if (ModConfig.INSTANCE.requireTargetCheck) {
                    if (anchorPos.getSquaredDistance(client.player.getPos()) > 36) {
                        cancel();
                        return;
                    }
                }
                
                ClickSimulator.rightClickBlock(anchorPos, Direction.UP, anchorPos.toCenterPos());
                transitionTo(MacroState.WAIT_GLOWSTONE_INSERTION_CONFIRM, 50);
                logDebug("Inserted glowstone");
                break;
                
            case WAIT_GLOWSTONE_INSERTION_CONFIRM:
                BlockState state = client.world.getBlockState(anchorPos);
                if (state.isOf(Blocks.RESPAWN_ANCHOR)) {
                    int charges = state.get(RespawnAnchorBlock.CHARGES);
                    if (charges > 0) {
                        if (ModConfig.INSTANCE.safeAnchorEnabled) {
                            transitionTo(MacroState.FIND_PROTECTION_POSITION, 0);
                        } else {
                            transitionTo(MacroState.SWITCH_TO_TOTEM, 0); // Không cần chờ đây, switch xong sẽ chờ
                        }
                    }
                } else {
                    cancel();
                }
                break;
                
            case FIND_PROTECTION_POSITION:
                this.protectionPos = ProtectionPlacementResolver.resolveProtectionPosition(anchorPos);
                if (this.protectionPos != null) {
                    transitionTo(MacroState.PLACE_PROTECTION_GLOWSTONE, getPlacementDelay());
                    logDebug("Found protection position: " + protectionPos);
                } else {
                    logDebug("Could not find protection position, cancelling Safe Anchor.");
                    cancel();
                }
                break;
                
            case PLACE_PROTECTION_GLOWSTONE:
                Direction facing = Direction.UP;
                Vec3d hitVec = protectionPos.toCenterPos();
                
                Direction sideToClick = null;
                for (Direction dir : Direction.values()) {
                    if (anchorPos.offset(dir).equals(protectionPos)) {
                        sideToClick = dir;
                        break;
                    }
                }
                
                if (sideToClick != null) {
                    ClickSimulator.rightClickBlock(anchorPos, sideToClick, anchorPos.toCenterPos().add(Vec3d.of(sideToClick.getVector()).multiply(0.5)));
                } else {
                    ClickSimulator.rightClickBlock(protectionPos, Direction.UP, hitVec);
                }
                
                transitionTo(MacroState.WAIT_PROTECTION_PLACEMENT_CONFIRM, 50);
                logDebug("Placed protection block");
                break;
                
            case WAIT_PROTECTION_PLACEMENT_CONFIRM:
                if (client.world.getBlockState(protectionPos).isOf(Blocks.GLOWSTONE)) {
                    transitionTo(MacroState.SWITCH_TO_TOTEM, 0); // Không cần chờ đây, switch xong sẽ chờ
                } else if (elapsed > 500) {
                    cancel();
                }
                break;
                
            case SWITCH_TO_TOTEM:
                int totemSlot = ModConfig.INSTANCE.totemSlot > 0 ? (ModConfig.INSTANCE.totemSlot - 1) : HotbarManager.findItemInHotbar(Items.TOTEM_OF_UNDYING);
                if (totemSlot != -1) {
                    HotbarManager.switchToSlot(totemSlot);
                    // Đợi đổi slot xong + đợi thao tác kích nổ
                    transitionTo(MacroState.WAIT_SWITCH_TOTEM_DELAY, getSwitchDelay() + getActivationDelay());
                    logDebug("Switched to totem slot: " + totemSlot);
                } else {
                    logDebug("Totem not found!");
                    cancel();
                }
                break;
                
            case WAIT_SWITCH_TOTEM_DELAY:
                transitionTo(MacroState.ACTIVATE_ANCHOR, 0);
                break;
                
            case ACTIVATE_ANCHOR:
                ClickSimulator.rightClickBlock(anchorPos, Direction.UP, anchorPos.toCenterPos());
                transitionTo(MacroState.WAIT_ACTIVATION_CONFIRM, 100);
                logDebug("Activated anchor");
                break;
                
            case WAIT_ACTIVATION_CONFIRM:
                logDebug("Sequence completed successfully");
                currentState = MacroState.IDLE;
                InventoryActionCoordinator.INSTANCE.releaseLock(InventoryActionCoordinator.ActionOwner.MAD_ANCHOR);
                InventoryActionCoordinator.INSTANCE.releaseLock(InventoryActionCoordinator.ActionOwner.SAFE_ANCHOR);
                break;
        }
    }
    
    private void transitionTo(MacroState nextState, long delayMs) {
        this.currentState = nextState;
        this.stateEnterTime = System.currentTimeMillis();
        this.currentDelayMs = delayMs;
    }
    
    private long getSwitchDelay() {
        return getRandomDelay(ModConfig.INSTANCE.switchDelayMinMs, ModConfig.INSTANCE.switchDelayMaxMs, ModConfig.INSTANCE.globalRandomization);
    }
    
    private long getInsertDelay() {
        return getRandomDelay(ModConfig.INSTANCE.insertDelayMinMs, ModConfig.INSTANCE.insertDelayMaxMs, ModConfig.INSTANCE.globalRandomization);
    }
    
    private long getPlacementDelay() {
        return getRandomDelay(ModConfig.INSTANCE.glowstonePlacementDelayMinMs, ModConfig.INSTANCE.glowstonePlacementDelayMaxMs, ModConfig.INSTANCE.glowstonePlacementRandom && ModConfig.INSTANCE.globalRandomization);
    }
    
    private long getActivationDelay() {
        return getRandomDelay(ModConfig.INSTANCE.activationDelayMinMs, ModConfig.INSTANCE.activationDelayMaxMs, ModConfig.INSTANCE.activationRandom && ModConfig.INSTANCE.globalRandomization);
    }
    
    private long getRandomDelay(int min, int max, boolean random) {
        if (!random || min >= max) {
            return min;
        }
        return min + (long)(Math.random() * (max - min));
    }
    
    public MacroState getCurrentState() {
        return currentState;
    }
    
    private void logDebug(String msg) {
        if (ModConfig.INSTANCE.debugMode) {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player != null) {
                client.player.sendMessage(Text.literal("[MadAnchor] " + msg), false);
            }
            System.out.println("[MadAnchor] " + msg);
        }
    }
}
