package net.madanchor.macro;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class ProtectionPlacementResolver {
    
    public static BlockPos resolveProtectionPosition(BlockPos anchorPos) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return null;
        
        World world = client.world;
        Vec3d playerPos = client.player.getEntityPos();
        
        BlockPos bestPos = null;
        double minDistance = Double.MAX_VALUE;
        
        // Find adjacent air block closest to the player
        for (Direction dir : Direction.values()) {
            BlockPos candidate = anchorPos.offset(dir);
            BlockState state = world.getBlockState(candidate);
            
            if (state.isReplaceable()) {
                double dist = candidate.toCenterPos().squaredDistanceTo(playerPos);
                if (dist < minDistance) {
                    // Check if player bounding box intersects
                    if (world.isSpaceEmpty(client.player, net.minecraft.block.Blocks.GLOWSTONE.getDefaultState().getCollisionShape(world, candidate).getBoundingBox().offset(candidate))) {
                        minDistance = dist;
                        bestPos = candidate;
                    }
                }
            }
        }
        
        return bestPos;
    }
}
