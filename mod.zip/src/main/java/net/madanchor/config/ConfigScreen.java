package net.madanchor.config;

import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class ConfigScreen {
    
    public static Screen createScreen(Screen parent) {
        ConfigBuilder builder = ConfigBuilder.create()
                .setParentScreen(parent)
                .setTitle(Text.literal("Mad Anchor & AutoTotem Settings"))
                .setSavingRunnable(ModConfig::save);

        ConfigEntryBuilder entryBuilder = builder.entryBuilder();

        // ---------------- AUTO TOTEM CATEGORY ----------------
        ConfigCategory totemCategory = builder.getOrCreateCategory(Text.literal("Auto Totem"));

        totemCategory.addEntry(entryBuilder.startBooleanToggle(Text.literal("Enable Auto Totem"), ModConfig.INSTANCE.autoTotem.enabled)
                .setDefaultValue(true)
                .setTooltip(Text.literal("Bật/Tắt tính năng Auto Totem"))
                .setSaveConsumer(newValue -> ModConfig.INSTANCE.autoTotem.enabled = newValue)
                .build());

        totemCategory.addEntry(entryBuilder.startBooleanToggle(Text.literal("Legit Swap Mode"), ModConfig.INSTANCE.autoTotem.legitSwap)
                .setDefaultValue(true)
                .setTooltip(Text.literal("Sử dụng chuột thật (mô phỏng) để lấy Totem thay vì Packet (Bypass AntiCheat tốt hơn)"))
                .setSaveConsumer(newValue -> ModConfig.INSTANCE.autoTotem.legitSwap = newValue)
                .build());

        totemCategory.addEntry(entryBuilder.startIntField(Text.literal("Min Random Delay (ms)"), ModConfig.INSTANCE.autoTotem.minDelayMs)
                .setDefaultValue(0)
                .setTooltip(Text.literal("Độ trễ tối thiểu (ms) trước khi thao tác (Base / Min Random Delay)"))
                .setMin(0).setMax(2000)
                .setSaveConsumer(newValue -> ModConfig.INSTANCE.autoTotem.minDelayMs = newValue)
                .build());

        totemCategory.addEntry(entryBuilder.startBooleanToggle(Text.literal("Add Random Delay"), ModConfig.INSTANCE.autoTotem.addRandomDelay)
                .setDefaultValue(true)
                .setTooltip(Text.literal("Cho phép độ trễ dao động ngẫu nhiên để đánh lừa AntiCheat"))
                .setSaveConsumer(newValue -> ModConfig.INSTANCE.autoTotem.addRandomDelay = newValue)
                .build());

        totemCategory.addEntry(entryBuilder.startIntSlider(Text.literal("Max Random Delay (ms)"), ModConfig.INSTANCE.autoTotem.maxDelayMs, 0, 1000)
                .setDefaultValue(500)
                .setTooltip(Text.literal("Độ trễ lớn nhất có thể quay ra (Max Random Delay)"))
                .setSaveConsumer(newValue -> ModConfig.INSTANCE.autoTotem.maxDelayMs = newValue)
                .build());

        // ---------------- MAD ANCHOR CATEGORY ----------------
        ConfigCategory anchorCategory = builder.getOrCreateCategory(Text.literal("Anchor Macro"));

        anchorCategory.addEntry(entryBuilder.startBooleanToggle(Text.literal("Enable Mad Anchor"), ModConfig.INSTANCE.madAnchorEnabled)
                .setDefaultValue(true)
                .setSaveConsumer(newValue -> ModConfig.INSTANCE.madAnchorEnabled = newValue)
                .build());

        anchorCategory.addEntry(entryBuilder.startBooleanToggle(Text.literal("Enable Safe Anchor (Glowstone Protection)"), ModConfig.INSTANCE.safeAnchorEnabled)
                .setDefaultValue(false)
                .setSaveConsumer(newValue -> ModConfig.INSTANCE.safeAnchorEnabled = newValue)
                .build());

        anchorCategory.addEntry(entryBuilder.startIntSlider(Text.literal("Min Switch Slot Delay (ms)"), ModConfig.INSTANCE.switchDelayMinMs, 0, 1000)
                .setDefaultValue(50)
                .setTooltip(Text.literal("Tốc độ chậm nhất để chờ sau khi lăn chuột / nhấn phím đổi slot"))
                .setSaveConsumer(newValue -> ModConfig.INSTANCE.switchDelayMinMs = newValue)
                .build());

        anchorCategory.addEntry(entryBuilder.startIntSlider(Text.literal("Max Switch Slot Delay (ms)"), ModConfig.INSTANCE.switchDelayMaxMs, 0, 1000)
                .setDefaultValue(150)
                .setTooltip(Text.literal("Tốc độ nhanh nhất để chờ sau khi đổi slot"))
                .setSaveConsumer(newValue -> ModConfig.INSTANCE.switchDelayMaxMs = newValue)
                .build());

        anchorCategory.addEntry(entryBuilder.startIntSlider(Text.literal("Min Insert Glowstone Delay (ms)"), ModConfig.INSTANCE.insertDelayMinMs, 0, 1000)
                .setDefaultValue(50)
                .setTooltip(Text.literal("Thời gian nạp Glowstone vào Anchor nhanh nhất"))
                .setSaveConsumer(newValue -> ModConfig.INSTANCE.insertDelayMinMs = newValue)
                .build());

        anchorCategory.addEntry(entryBuilder.startIntSlider(Text.literal("Max Insert Glowstone Delay (ms)"), ModConfig.INSTANCE.insertDelayMaxMs, 0, 1000)
                .setDefaultValue(150)
                .setTooltip(Text.literal("Thời gian nạp Glowstone vào Anchor chậm nhất"))
                .setSaveConsumer(newValue -> ModConfig.INSTANCE.insertDelayMaxMs = newValue)
                .build());

        anchorCategory.addEntry(entryBuilder.startIntSlider(Text.literal("Min Activation Delay (ms)"), ModConfig.INSTANCE.activationDelayMinMs, 0, 1000)
                .setDefaultValue(50)
                .setTooltip(Text.literal("Thời gian kích nổ Anchor bằng Totem nhanh nhất"))
                .setSaveConsumer(newValue -> ModConfig.INSTANCE.activationDelayMinMs = newValue)
                .build());

        anchorCategory.addEntry(entryBuilder.startIntSlider(Text.literal("Max Activation Delay (ms)"), ModConfig.INSTANCE.activationDelayMaxMs, 0, 1000)
                .setDefaultValue(200)
                .setTooltip(Text.literal("Thời gian kích nổ Anchor chậm nhất"))
                .setSaveConsumer(newValue -> ModConfig.INSTANCE.activationDelayMaxMs = newValue)
                .build());
                
        // ---------------- MISC CATEGORY ----------------
        ConfigCategory miscCategory = builder.getOrCreateCategory(Text.literal("Misc / HUD"));
        
        miscCategory.addEntry(entryBuilder.startBooleanToggle(Text.literal("Enable HUD Overlay"), ModConfig.INSTANCE.enableHud)
                .setDefaultValue(true)
                .setSaveConsumer(newValue -> ModConfig.INSTANCE.enableHud = newValue)
                .build());
                
        miscCategory.addEntry(entryBuilder.startBooleanToggle(Text.literal("Global Randomization"), ModConfig.INSTANCE.globalRandomization)
                .setDefaultValue(true)
                .setSaveConsumer(newValue -> ModConfig.INSTANCE.globalRandomization = newValue)
                .build());

        return builder.build();
    }
}
