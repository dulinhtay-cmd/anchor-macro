package net.madanchor.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ModConfig {
    private static final File CONFIG_FILE = new File(FabricLoader.getInstance().getConfigDir().toFile(), "madanchor.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static ModConfig INSTANCE = new ModConfig();

    public boolean madAnchorEnabled = true;
    public boolean safeAnchorEnabled = false;
    public boolean clickSimulatorEnabled = true;
    
    public AutoTotemConfig autoTotem = new AutoTotemConfig();
    
    // Slots: 0 = Auto, 1-9 = specific slot
    public int glowstoneSlot = 0; 
    public int totemSlot = 0;

    public int switchDelayMinMs = 50;
    public int switchDelayMaxMs = 150;

    public int insertDelayMinMs = 50;
    public int insertDelayMaxMs = 150;

    public int glowstonePlacementDelayMinMs = 50;
    public int glowstonePlacementDelayMaxMs = 200;
    public boolean glowstonePlacementRandom = true;

    public int activationDelayMinMs = 50;
    public int activationDelayMaxMs = 200;
    public boolean activationRandom = true;

    public boolean globalRandomization = true;

    public int actionTimeoutMs = 3000;
    
    public boolean requireItemCheck = true;
    public boolean requireTargetCheck = true;
    public boolean requirePlayerStateCheck = true;
    
    public boolean enableHud = true;
    public boolean debugMode = false;

    public static void load() {
        if (CONFIG_FILE.exists()) {
            try (FileReader reader = new FileReader(CONFIG_FILE)) {
                INSTANCE = GSON.fromJson(reader, ModConfig.class);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            save();
        }
    }

    public static void save() {
        try (FileWriter writer = new FileWriter(CONFIG_FILE)) {
            GSON.toJson(INSTANCE, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
