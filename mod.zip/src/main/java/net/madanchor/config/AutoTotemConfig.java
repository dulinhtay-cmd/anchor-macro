package net.madanchor.config;

public class AutoTotemConfig {
    public boolean enabled = true;
    public boolean legitSwap = true;
    public boolean checkPotionEffects = true;
    public int minDelayMs = 0;
    public int maxDelayMs = 500;
    public boolean addRandomDelay = true;
}
