package net.madanchor.input;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.ActionResult;

public class ClickSimulator {
    public static boolean rightClickBlock(BlockPos pos, Direction side, Vec3d hitVec) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.interactionManager == null || client.player == null || client.world == null) {
            return false;
        }

        BlockHitResult hitResult = new BlockHitResult(hitVec, side, pos, false);
        ActionResult result = client.interactionManager.interactBlock(client.player, Hand.MAIN_HAND, hitResult);
        
        if (result.isAccepted()) {
            client.player.swingHand(Hand.MAIN_HAND);
            return true;
        }
        return false;
    }
}
