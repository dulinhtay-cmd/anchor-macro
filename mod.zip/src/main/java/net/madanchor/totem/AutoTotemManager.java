package net.madanchor.totem;

import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import net.madanchor.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.screen.slot.SlotActionType;

import java.util.ArrayList;

public class AutoTotemManager {

    private static final ArrayList<Packet<?>> packetsToSend = new ArrayList<>();

    public static void onTotemUse(ItemStack floatingItem) {
        if (!ModConfig.INSTANCE.autoTotem.enabled) return;
        if (!floatingItem.isOf(Items.TOTEM_OF_UNDYING)) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;

        if (ModConfig.INSTANCE.autoTotem.checkPotionEffects) {
            if (!client.player.hasStatusEffect(StatusEffects.FIRE_RESISTANCE)) return;
            if (!client.player.hasStatusEffect(StatusEffects.REGENERATION)) return;
        }

        if (!InventoryActionCoordinator.INSTANCE.requestLock(InventoryActionCoordinator.ActionOwner.AUTO_TOTEM)) {
            return; // Failed to get lock, Mad Anchor or something higher priority is working
        }

        PlayerInventory inventory = client.player.getInventory();

        // Step 1: Check if there's a totem in the hotbar
        int hotbarSlotWithTotem = TotemHelper.findTotemInHotbar();
        if (hotbarSlotWithTotem != -1) {
            if (ModConfig.INSTANCE.autoTotem.legitSwap) {
                // Not fully implemented for legit swap from hotbar in original, it falls back to packets for hotbar swap
                applyDelaysAndSwapHotbar(inventory, hotbarSlotWithTotem);
            } else {
                applyDelaysAndSwapHotbar(inventory, hotbarSlotWithTotem);
            }
            return;
        }

        // Only do legit swap if enabled, else we could packet swap from inventory but XelAutoTotem only had legit from inventory
        if (ModConfig.INSTANCE.autoTotem.legitSwap) {
            // Step 2: Check for empty hotbar slots
            int emptyHotbarSlot = TotemHelper.findEmptyHotbarSlot();
            if (emptyHotbarSlot != -1) {
                TotemHelper.onInventoryScreenOpen(); // Start listening for the totem slot
                return;
            }

            // Step 3: No totem in the hotbar and no empty hotbar slot
            int totemSlot = getTotemSlot(inventory);
            if (totemSlot != -1) {
                TotemHelper.onInventoryScreenOpen();
            } else {
                InventoryActionCoordinator.INSTANCE.releaseLock(InventoryActionCoordinator.ActionOwner.AUTO_TOTEM);
            }
        } else {
            // If legit swap is false, let's do a packet swap from inventory if possible
            int totemSlot = getTotemSlot(inventory);
            if (totemSlot != -1) {
                swapTotemPacket(inventory, totemSlot);
            } else {
                InventoryActionCoordinator.INSTANCE.releaseLock(InventoryActionCoordinator.ActionOwner.AUTO_TOTEM);
            }
        }
    }

    private static int getTotemSlot(PlayerInventory inventory) {
        for (int i = 9; i < inventory.main.size(); i++) { // Check inventory first
            ItemStack stack = inventory.main.get(i);
            if (!stack.isEmpty() && stack.isOf(Items.TOTEM_OF_UNDYING)) return i;
        }
        return -1;
    }

    private static void swapTotemPacket(PlayerInventory inventory, int inventorySlot) {
        MinecraftClient client = MinecraftClient.getInstance();
        client.execute(() -> {
            try {
                int syncId = inventory.player.currentScreenHandler.syncId;
                int revision = inventory.player.currentScreenHandler.getRevision();
                
                // Swap with offhand (slot 45 in player inventory screen handler)
                packetsToSend.add(new ClickSlotC2SPacket(syncId, revision, inventorySlot < 9 ? inventorySlot + 36 : inventorySlot, 40, SlotActionType.SWAP, inventory.getStack(inventorySlot).copy(), new Int2ObjectArrayMap<>()));

                executePackets();
            } finally {
                InventoryActionCoordinator.INSTANCE.releaseLock(InventoryActionCoordinator.ActionOwner.AUTO_TOTEM);
            }
        });
    }

    private static void applyDelaysAndSwapHotbar(PlayerInventory inventory, int hotbarSlotWithTotem) {
        MinecraftClient client = MinecraftClient.getInstance();
        int totalDelay = TotemHelper.getTotalDelay();
        int stepDelay = totalDelay / 3;

        // Run this in a separate thread so it doesn't block the client execute queue
        new Thread(() -> {
            try {
                // First delay
                Thread.sleep(stepDelay);

                // Select the slot
                packetsToSend.add(new UpdateSelectedSlotC2SPacket(hotbarSlotWithTotem));

                // Second delay
                Thread.sleep(stepDelay);

                // Need syncId and revision from main thread
                client.execute(() -> {
                    int syncId = inventory.player.currentScreenHandler.syncId;
                    int revision = inventory.player.currentScreenHandler.getRevision();
                    
                    // In 1.21.1 player inventory, offhand is slot index 45. In ClickSlotC2SPacket for player inventory, the slot index for offhand is 45.
                    // The 'button' parameter for SWAP (if slot is in hotbar) would be the hotbar slot index (0-8) or 40 for offhand swap in some contexts.
                    // XelAutoTotem uses: new ClickSlotC2SPacket(..., 45, 0, SlotActionType.SWAP, ...) which implies hovering over offhand (45) and swapping with hotbar slot 0? Or maybe it just swaps what is currently selected.
                    // Let's use the standard offhand swap which is button 40 with SlotActionType.SWAP
                    packetsToSend.add(new ClickSlotC2SPacket(syncId, revision, 45, hotbarSlotWithTotem, SlotActionType.SWAP, inventory.getStack(hotbarSlotWithTotem).copy(), new Int2ObjectArrayMap<>()));
                });

                // Final delay
                Thread.sleep(stepDelay);

                // Send the packets
                executePackets();

            } catch (InterruptedException e) {
                e.printStackTrace();
                Thread.currentThread().interrupt();
            } finally {
                InventoryActionCoordinator.INSTANCE.releaseLock(InventoryActionCoordinator.ActionOwner.AUTO_TOTEM);
            }
        }).start();
    }

    private static void executePackets() {
        MinecraftClient.getInstance().execute(() -> {
            ClientPlayNetworkHandler networkHandler = MinecraftClient.getInstance().getNetworkHandler();
            if (networkHandler != null && !packetsToSend.isEmpty()) {
                packetsToSend.forEach(networkHandler::sendPacket);
                packetsToSend.clear();
            }
        });
    }
}
