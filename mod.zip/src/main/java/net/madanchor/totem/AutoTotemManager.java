package net.madanchor.totem;

import net.madanchor.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

import java.util.concurrent.atomic.AtomicBoolean;

public class AutoTotemManager {
    private static final AtomicBoolean PROCESSING = new AtomicBoolean(false);
    private static volatile long lastTriggerMs = 0L;
    private static final long TRIGGER_COOLDOWN_MS = 1500L;

    static void finishProcessing() {
        PROCESSING.set(false);
    }

    public static void onTotemUse(ItemStack floatingItem) {
        if (!ModConfig.INSTANCE.autoTotem.enabled) return;
        if (!floatingItem.isOf(Items.TOTEM_OF_UNDYING)) return;

        long now = System.currentTimeMillis();
        if (now - lastTriggerMs < TRIGGER_COOLDOWN_MS) return;
        if (!PROCESSING.compareAndSet(false, true)) return;
        lastTriggerMs = now;

        try {
            handleTotemUse();
        } catch (Throwable t) {
            System.err.println("[MadAnchor] AutoTotem error: " + t);
            t.printStackTrace();
            InventoryActionCoordinator.INSTANCE.releaseLock(InventoryActionCoordinator.ActionOwner.AUTO_TOTEM);
            PROCESSING.set(false);
        }
    }

    private static void handleTotemUse() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) {
            PROCESSING.set(false);
            return;
        }

        if (ModConfig.INSTANCE.autoTotem.checkPotionEffects) {
            if (!client.player.hasStatusEffect(StatusEffects.FIRE_RESISTANCE)) {
                PROCESSING.set(false);
                return;
            }
            if (!client.player.hasStatusEffect(StatusEffects.REGENERATION)) {
                PROCESSING.set(false);
                return;
            }
        }

        if (!InventoryActionCoordinator.INSTANCE.requestLock(InventoryActionCoordinator.ActionOwner.AUTO_TOTEM)) {
            PROCESSING.set(false);
            return;
        }

        PlayerInventory inventory = client.player.getInventory();
        int hotbarSlotWithTotem = TotemHelper.findTotemInHotbar();
        if (hotbarSlotWithTotem != -1) {
            applyDelaysAndSwapHotbar(hotbarSlotWithTotem);
            return;
        }

        if (ModConfig.INSTANCE.autoTotem.legitSwap) {
            int emptyHotbarSlot = TotemHelper.findEmptyHotbarSlot();
            if (emptyHotbarSlot != -1) {
                TotemHelper.onInventoryScreenOpen();
                return;
            }

            int totemSlot = getTotemSlot(inventory);
            if (totemSlot != -1) {
                TotemHelper.onInventoryScreenOpen();
            } else {
                releaseProcessing();
            }
        } else {
            int totemSlot = getTotemSlot(inventory);
            if (totemSlot != -1) {
                swapTotemPacket(totemSlot);
            } else {
                releaseProcessing();
            }
        }
    }

    private static void releaseProcessing() {
        InventoryActionCoordinator.INSTANCE.releaseLock(InventoryActionCoordinator.ActionOwner.AUTO_TOTEM);
        PROCESSING.set(false);
    }

    private static int getTotemSlot(PlayerInventory inventory) {
        for (int i = 9; i < inventory.getMainStacks().size(); i++) {
            ItemStack stack = inventory.getMainStacks().get(i);
            if (!stack.isEmpty() && stack.isOf(Items.TOTEM_OF_UNDYING)) return i;
        }
        return -1;
    }

    private static void swapTotemPacket(int inventorySlot) {
        MinecraftClient client = MinecraftClient.getInstance();
        client.execute(() -> {
            try {
                if (client.interactionManager == null || client.player == null || client.world == null) return;
                int syncId = client.player.currentScreenHandler.syncId;
                int screenSlot = inventorySlot < 9 ? inventorySlot + 36 : inventorySlot;
                client.interactionManager.clickSlot(syncId, screenSlot, 40, SlotActionType.SWAP, client.player);
            } finally {
                releaseProcessing();
            }
        });
    }

    private static void applyDelaysAndSwapHotbar(int hotbarSlotWithTotem) {
        MinecraftClient client = MinecraftClient.getInstance();
        int totalDelay = TotemHelper.getTotalDelay();
        int stepDelay = Math.max(1, totalDelay / 3);

        new Thread(() -> {
            try {
                Thread.sleep(stepDelay);
                client.execute(() -> {
                    if (client.interactionManager != null && client.player != null && client.world != null) {
                        int syncId = client.player.currentScreenHandler.syncId;
                        client.interactionManager.clickSlot(syncId, 45, hotbarSlotWithTotem, SlotActionType.SWAP, client.player);
                    }
                });
                Thread.sleep(stepDelay);
                Thread.sleep(stepDelay);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } finally {
                releaseProcessing();
            }
        }, "MadAnchor-AutoTotem").start();
    }
}
