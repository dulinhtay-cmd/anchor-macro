package net.madanchor.totem;

import net.madanchor.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

import java.util.ArrayList;

public class AutoTotemManager {


    public static void onTotemUse(ItemStack floatingItem) {
        if (!ModConfig.INSTANCE.autoTotem.enabled) return;
        if (!floatingItem.isOf(Items.TOTEM_OF_UNDYING)) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;

        if (ModConfig.INSTANCE.autoTotem.checkPotionEffects) {
            if (!client.player.hasStatusEffect(StatusEffects.FIRE_RESISTANCE)) return;
            if (!client.player.hasStatusEffect(StatusEffects.REGENERATION)) return;
        }

        if (!InventoryActionCoordinator.INSTANCE.requestLock(InventoryActionCoordinator.ActionOwner.AUTO_TOTEM)) {
            return; // Failed to get lock, Mad Anchor or something higher priority is working
        }

        PlayerInventory inventory = client.player.getInventory();

        // Step 1: Check if there's a totem in the hotbar
        int hotbarSlotWithTotem = TotemHelper.findTotemInHotbar();
        if (hotbarSlotWithTotem != -1) {
            if (ModConfig.INSTANCE.autoTotem.legitSwap) {
                // Not fully implemented for legit swap from hotbar in original, it falls back to packets for hotbar swap
                applyDelaysAndSwapHotbar(inventory, hotbarSlotWithTotem);
            } else {
                applyDelaysAndSwapHotbar(inventory, hotbarSlotWithTotem);
            }
            return;
        }

        // Only do legit swap if enabled, else we could packet swap from inventory but XelAutoTotem only had legit from inventory
        if (ModConfig.INSTANCE.autoTotem.legitSwap) {
            // Step 2: Check for empty hotbar slots
            int emptyHotbarSlot = TotemHelper.findEmptyHotbarSlot();
            if (emptyHotbarSlot != -1) {
                TotemHelper.onInventoryScreenOpen(); // Start listening for the totem slot
                return;
            }

            // Step 3: No totem in the hotbar and no empty hotbar slot
            int totemSlot = getTotemSlot(inventory);
            if (totemSlot != -1) {
                TotemHelper.onInventoryScreenOpen();
            } else {
                InventoryActionCoordinator.INSTANCE.releaseLock(InventoryActionCoordinator.ActionOwner.AUTO_TOTEM);
            }
        } else {
            // If legit swap is false, let's do a packet swap from inventory if possible
            int totemSlot = getTotemSlot(inventory);
            if (totemSlot != -1) {
                swapTotemPacket(inventory, totemSlot);
            } else {
                InventoryActionCoordinator.INSTANCE.releaseLock(InventoryActionCoordinator.ActionOwner.AUTO_TOTEM);
            }
        }
    }

    private static int getTotemSlot(PlayerInventory inventory) {
        for (int i = 9; i < inventory.getMainStacks().size(); i++) { // Check inventory first
            ItemStack stack = inventory.getMainStacks().get(i);
            if (!stack.isEmpty() && stack.isOf(Items.TOTEM_OF_UNDYING)) return i;
        }
        return -1;
    }

    private static void swapTotemPacket(PlayerInventory inventory, int inventorySlot) {
        MinecraftClient client = MinecraftClient.getInstance();
        client.execute(() -> {
            try {
                if (client.interactionManager == null || client.player == null) return;
                int syncId = client.player.currentScreenHandler.syncId;
                int screenSlot = inventorySlot < 9 ? inventorySlot + 36 : inventorySlot;
                // SWAP button 40 exchanges the clicked inventory slot with the offhand slot.
                client.interactionManager.clickSlot(syncId, screenSlot, 40, SlotActionType.SWAP, client.player);
            } finally {
                InventoryActionCoordinator.INSTANCE.releaseLock(InventoryActionCoordinator.ActionOwner.AUTO_TOTEM);
            }
        });
    }

    private static void applyDelaysAndSwapHotbar(PlayerInventory inventory, int hotbarSlotWithTotem) {
        MinecraftClient client = MinecraftClient.getInstance();
        int totalDelay = TotemHelper.getTotalDelay();
        int stepDelay = Math.max(1, totalDelay / 3);

        new Thread(() -> {
            try {
                Thread.sleep(stepDelay);
                client.execute(() -> {
                    if (client.interactionManager != null && client.player != null) {
                        int syncId = client.player.currentScreenHandler.syncId;
                        // Player inventory screen: offhand is slot 45; SWAP button selects hotbar slot 0..8.
                        client.interactionManager.clickSlot(syncId, 45, hotbarSlotWithTotem, SlotActionType.SWAP, client.player);
                    }
                });
                Thread.sleep(stepDelay);
                Thread.sleep(stepDelay);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } finally {
                InventoryActionCoordinator.INSTANCE.releaseLock(InventoryActionCoordinator.ActionOwner.AUTO_TOTEM);
            }
        }).start();
    }

}
