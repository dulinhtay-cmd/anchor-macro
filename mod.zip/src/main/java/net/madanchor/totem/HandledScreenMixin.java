package net.madanchor.totem;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Minecraft 1.21.11-compatible inventory hook.
 *
 * Older MadAnchor builds injected into HandledScreen#drawSlot using the
 * 1.21.1 target. The 1.21.11 client changed the rendering path, so that
 * old refmap can fail during mixin application. We hook drawSlots instead,
 * which is present in 1.21.11, and scan the handler slots ourselves.
 */
@Mixin(HandledScreen.class)
public abstract class HandledScreenMixin {

    @Shadow protected int x;
    @Shadow protected int y;
    @Shadow protected ScreenHandler handler;

    @Inject(method = "drawSlots", at = @At("HEAD"))
    private void madAnchor$findTotemSlot(DrawContext context, int mouseX, int mouseY, CallbackInfo ci) {
        if (!TotemHelper.isListeningForTotemSlot()) return;

        for (Slot slot : handler.slots) {
            ItemStack stack = slot.getStack();
            if (stack.isOf(Items.TOTEM_OF_UNDYING)) {
                TotemHelper.setTotemSlotCoordinates(slot.x + x, slot.y + y);
                TotemHelper.stopListeningForTotemSlot();
                TotemHelper.smoothMoveCursorToTotemSlot();
                break;
            }
        }
    }
}
