package net.madanchor.totem;

import net.madanchor.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.Window;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Items;
import net.minecraft.screen.NamedScreenHandlerFactory;

import java.awt.AWTException;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.Robot;
import java.util.Random;

public class TotemHelper {

    private static boolean listeningForNextDraw = false;
    private static int totemX = -1;
    private static int totemY = -1;
    private static final Random random = new Random();

    public static void onInventoryScreenOpen() {
        listeningForNextDraw = true;
        totemX = -1;
        totemY = -1;

        // Open the inventory client-side
        MinecraftClient client = MinecraftClient.getInstance();
        client.execute(() -> {
            if (client.player != null) {
                // In Fabric 1.21.x, we don't openHandledScreen with the player's own handler directly like this easily if it's the inventory
                // However, we can open the creative or survival inventory screen. Actually, let's just let the client open the inventory.
                // We'll mimic XelAutoTotem's implementation and adjust it for 1.21
                client.setScreen(new net.minecraft.client.gui.screen.ingame.InventoryScreen(client.player));
            }
        });
    }

    public static boolean isListeningForTotemSlot() {
        return listeningForNextDraw;
    }

    public static void stopListeningForTotemSlot() {
        listeningForNextDraw = false;
    }

    public static void setTotemSlotCoordinates(int x, int y) {
        int randomOffsetX = random.nextInt(7) - 3; // Random number between -3 and 3
        int randomOffsetY = random.nextInt(7) - 3; // Random number between -3 and 3

        totemX = x + 8 + randomOffsetX;  // Center the cursor on the slot and add random offset
        totemY = y + 8 + randomOffsetY;  // Center the cursor on the slot and add random offset
    }

    public static void smoothMoveCursorToTotemSlot() {
        if (totemX == -1 || totemY == -1) return;

        // Run this asynchronously so it doesn't block the main thread like XelAutoTotem might if called synchronously
        new Thread(() -> {
            try {
                Robot robot = new Robot();
                Window win = MinecraftClient.getInstance().getWindow();
                double scaleFactor = win.getScaleFactor();

                int finalX = (int) (totemX * scaleFactor);
                int finalY = (int) (totemY * scaleFactor);

                Point currentMousePos = MouseInfo.getPointerInfo().getLocation();
                int startX = currentMousePos.x;
                int startY = currentMousePos.y;

                // Generate a random height for the parabolic arc
                int arcHeight = random.nextInt(30) + 20;

                // Calculate the delay per action step
                int totalDelay = getTotalDelay();
                int steps = 50;
                int delayPerStep = totalDelay / steps;

                if (delayPerStep <= 0) delayPerStep = 1;

                // Lock the cursor by continuously correcting its position if moved
                for (int i = 0; i < steps; i++) {
                    double t = (double) i / (steps - 1);
                    double smoothStep = t * t * (3 - 2 * t); // Smoothstep interpolation

                    // Parabolic interpolation with a small randomized height
                    int x = startX + (int) ((finalX - startX) * smoothStep);
                    int y = startY + (int) ((finalY - startY) * smoothStep - (4 * arcHeight * smoothStep * (1 - smoothStep)));

                    // Move mouse
                    robot.mouseMove(x, y);

                    try {
                        Thread.sleep(delayPerStep);
                    } catch (InterruptedException ignored) {
                    }
                }

                // Ensure the mouse is exactly on the slot at the end
                robot.mouseMove(finalX, finalY);

                // Small delay before clicking to ensure timing consistency
                Thread.sleep(getTotalDelay());

            } catch (AWTException | InterruptedException e) {
                e.printStackTrace();
            } finally {
                InventoryActionCoordinator.INSTANCE.releaseLock(InventoryActionCoordinator.ActionOwner.AUTO_TOTEM);
            }
        }).start();
    }

    public static int getTotalDelay() {
        int min = ModConfig.INSTANCE.autoTotem.minDelayMs;
        int max = ModConfig.INSTANCE.autoTotem.maxDelayMs;
        if (ModConfig.INSTANCE.autoTotem.addRandomDelay && max > min) {
            return min + random.nextInt(max - min + 1);
        }
        return min;
    }

    public static int findEmptyHotbarSlot() {
        PlayerInventory inventory = MinecraftClient.getInstance().player.getInventory();
        for (int i = 0; i < 9; i++) {
            if (inventory.main.get(i).isEmpty()) {
                return i;
            }
        }
        return -1;
    }

    public static int findTotemInHotbar() {
        PlayerInventory inventory = MinecraftClient.getInstance().player.getInventory();
        for (int i = 0; i < 9; i++) {
            if (inventory.main.get(i).isOf(Items.TOTEM_OF_UNDYING)) {
                return i;
            }
        }
        return -1;
    }
}
