package net.madanchor.totem;

import net.madanchor.config.ModConfig;

public class InventoryActionCoordinator {
    public static final InventoryActionCoordinator INSTANCE = new InventoryActionCoordinator();

    private ActionOwner currentOwner = null;
    private long lockTime = 0;
    private static final long TIMEOUT_MS = 3000;

    public enum ActionOwner {
        AUTO_TOTEM(100),
        SAFE_ANCHOR(50),
        MAD_ANCHOR(10);

        private final int priority;

        ActionOwner(int priority) {
            this.priority = priority;
        }

        public int getPriority() {
            return priority;
        }
    }

    public boolean requestLock(ActionOwner requester) {
        long now = System.currentTimeMillis();
        
        // If locked and timed out, release the lock
        if (currentOwner != null && now - lockTime > TIMEOUT_MS) {
            currentOwner = null;
        }

        // If no one owns the lock, grant it
        if (currentOwner == null) {
            currentOwner = requester;
            lockTime = now;
            return true;
        }

        // If requester is already the owner, renew the lock
        if (currentOwner == requester) {
            lockTime = now;
            return true;
        }

        // If the requester has a higher priority, preempt the current owner
        if (requester.getPriority() > currentOwner.getPriority()) {
            currentOwner = requester;
            lockTime = now;
            return true;
        }

        // Otherwise, denied
        return false;
    }

    public void releaseLock(ActionOwner owner) {
        if (currentOwner == owner) {
            currentOwner = null;
        }
    }
}
