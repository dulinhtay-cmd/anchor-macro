MadAnchor 1.0.0 - Minecraft 1.21.11 + Fabric

This source is patched to avoid the old HandledScreen#drawSlot mixin target.
Minecraft 1.21.11 still exposes HandledScreen#drawSlots(DrawContext,int,int),
so HandledScreenMixin now injects into drawSlots and scans handler slots.

Build on Windows:
1. Install/use Java 21.
2. Open this folder in CMD.
3. Run: build_windows.bat
4. If successful, take the JAR from build\libs\.
5. Replace the old madanchor JAR in your Fabric 1.21.11 mods folder.

Important: the build needs internet access on first run so Gradle/Loom can
resolve Minecraft/Yarn/Fabric dependencies. Do NOT put two MadAnchor jars
in the mods folder at the same time.
